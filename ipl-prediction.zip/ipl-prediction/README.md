# IPL Prediction Project

This project is designed to predict the outcomes of IPL matches using machine learning techniques. It utilizes historical match data to train a model that can make predictions based on various features related to the teams and match conditions.

## Project Structure

The project is organized as follows:

```
ipl-prediction
├── data
│   ├── preprocessed_data.pkl       # Preprocessed data used for training the model
│   ├── trained_model.pkl           # Trained machine learning model for predictions
│   └── X_test.pkl                  # Test dataset for evaluating model performance
├── src
│   ├── predictor_3.py              # Loads data, selects test cases, encodes features, and makes predictions
│   └── user_input_predictor.py     # Handles user input and retrieves relevant features for predictions
├── requirements.txt                 # Lists project dependencies
└── README.md                        # Documentation for the project
```

## Installation

To set up the project, follow these steps:

1. Clone the repository:
   ```
   git clone <repository-url>
   cd ipl-prediction
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

1. **Running the Predictor**: 
   - To run the model with a random test case, execute the `predictor_3.py` script:
     ```
     python src/predictor_3.py
     ```

2. **User Input for Predictions**:
   - To input specific teams and retrieve relevant features, run the `user_input_predictor.py` script:
     ```
     python src/user_input_predictor.py
     ```
   - Follow the prompts to enter `team1`, `team2`, `toss winning team`, and `toss decision`.

## Data Files

- **preprocessed_data.pkl**: Contains the cleaned and processed data used for training the model, including features and labels.
- **trained_model.pkl**: Stores the trained machine learning model that will be used for making predictions.
- **X_test.pkl**: Contains the test dataset that can be used to evaluate the model's performance.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License. See the LICENSE file for details.