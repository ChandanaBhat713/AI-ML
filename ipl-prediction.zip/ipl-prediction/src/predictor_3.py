import numpy as np
import pandas as pd
import joblib

# Load preprocessed data, trained model, and X_test
X, y, label_encoders, scaler, categorical_cols, numerical_cols = joblib.load('preprocessed_data.pkl')
best_model = joblib.load('trained_model.pkl')
X_test = joblib.load('X_test.pkl')

# Select a random row from the X_test dataset to use as the custom test case
selected_row = X_test.sample(n=1).iloc[0]

# Extract values from the selected row
team1 = label_encoders['team1'].inverse_transform([int(selected_row['team1'])])[0]
team2 = label_encoders['team2'].inverse_transform([int(selected_row['team2'])])[0]
team1_win_percentage = selected_row['team1_win_percentage']
team2_win_percentage = selected_row['team2_win_percentage']
head_to_head = selected_row['head_to_head']
home_advantage = selected_row['home_advantage']
toss_winner = label_encoders['toss_winner'].inverse_transform([int(selected_row['toss_winner'])])[0]
toss_decision = label_encoders['toss_decision'].inverse_transform([int(selected_row['toss_decision'])])[0]
batter_form = selected_row['batter_form']
bowler_form = selected_row['bowler_form']
venue = label_encoders['venue'].inverse_transform([int(selected_row['venue'])])[0]
venue_win_percentage = selected_row['venue_win_percentage']
day_night = selected_row['day_night']
team1_recent_form = selected_row['team1_recent_form']
team2_recent_form = selected_row['team2_recent_form']
team1_key_player_available = selected_row['team1_key_player_available']
team2_key_player_available = selected_row['team2_key_player_available']

# Create the custom test case DataFrame
custom_test_case = pd.DataFrame({
    'team1': [team1],
    'team2': [team2],
    'team1_win_percentage': [team1_win_percentage],
    'team2_win_percentage': [team2_win_percentage],
    'head_to_head': [head_to_head],
    'home_advantage': [home_advantage],
    'toss_winner': [toss_winner],
    'toss_decision': [toss_decision],
    'batter_form': [batter_form],
    'bowler_form': [bowler_form],
    'venue': [venue],
    'venue_win_percentage': [venue_win_percentage],
    'day_night': [day_night],
    'team1_recent_form': [team1_recent_form],
    'team2_recent_form': [team2_recent_form],
    'team1_key_player_available': [team1_key_player_available],
    'team2_key_player_available': [team2_key_player_available]
})

# Encode the custom test case
for col in categorical_cols:
    custom_test_case[col] = custom_test_case[col].apply(
        lambda x: label_encoders[col].transform([x])[0] if x in label_encoders[col].classes_ else -1
    )

# Scale numerical features
custom_test_case[numerical_cols] = scaler.transform(custom_test_case[numerical_cols].astype(float))

# Convert categorical boolean/int features to int
custom_test_case['home_advantage'] = custom_test_case['home_advantage'].astype(int)
custom_test_case['day_night'] = custom_test_case['day_night'].astype(int)
custom_test_case['team1_key_player_available'] = custom_test_case['team1_key_player_available'].astype(int)
custom_test_case['team2_key_player_available'] = custom_test_case['team2_key_player_available'].astype(int)

# Ensure all columns are of the correct dtype (float)
custom_test_case = custom_test_case.astype(float)

# Make a prediction
prediction_proba = best_model.predict_proba(custom_test_case)

# Get the indices of the teams in the match
team1_index = label_encoders['winner'].transform([team1])[0]
team2_index = label_encoders['winner'].transform([team2])[0]

# Get the probabilities for the teams in the match
team1_proba = prediction_proba[0][team1_index]
team2_proba = prediction_proba[0][team2_index]

# Determine the predicted winner based on the highest probability
if team1_proba > team2_proba:
    predicted_winner = team1
else:
    predicted_winner = team2

# Decode the custom test case for printing
decoded_custom_test_case = custom_test_case.copy()
for col in categorical_cols:
    decoded_custom_test_case[col] = label_encoders[col].inverse_transform(custom_test_case[col].astype(int))

# Print the decoded custom test case and the predicted winner
print("team1:", decoded_custom_test_case['team1'].values[0])
print("team2:", decoded_custom_test_case['team2'].values[0])
print("toss_winner:", decoded_custom_test_case['toss_winner'].values[0])
print("toss_decision:", decoded_custom_test_case['toss_decision'].values[0])
print("venue:", decoded_custom_test_case['venue'].values[0])
print("Predicted winner:", predicted_winner)